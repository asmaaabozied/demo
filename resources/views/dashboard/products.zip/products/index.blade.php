<x-layout :title="request('in_stock')=='false' ? trans('products.out_of_stock') : trans('products.plural')" :breadcrumbs="['dashboard.products.index']">
    @include('dashboard.products.partials.list')
</x-layout>
