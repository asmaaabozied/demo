

<x-layout :title="trans('products.actions.create')" :breadcrumbs="['dashboard.products.create']">
    @include('dashboard.products.partials.create-box')
</x-layout>