@extends('layouts.yo3an_wagef.master', ['title' => auth()->user()->name])

@section('content')

@endsection