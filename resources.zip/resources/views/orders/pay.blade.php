@extends('layouts.yo3an_wagef.master')

@section('content')
<div class="container">
 Show Payment Form
</div>
@endsection
