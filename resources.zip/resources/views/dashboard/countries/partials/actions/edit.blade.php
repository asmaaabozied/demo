@can('update', $country)
    <a href="{{ route('dashboard.countries.edit', $country) }}" class="btn btn-outline-primary btn-sm">
        <i class="fas fa fa-fw fa-edit"></i>
    </a>
@endcan
