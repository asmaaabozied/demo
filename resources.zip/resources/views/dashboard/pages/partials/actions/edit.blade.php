@can('update', $page)
    <a href="{{ route('dashboard.pages.edit', $page) }}" class="btn btn-outline-primary btn-sm">
        <i class="fas fa fa-fw fa-edit"></i>
    </a>
@endcan
