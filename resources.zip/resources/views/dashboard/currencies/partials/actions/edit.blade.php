@can('update', $currency)
    <a href="{{ route('dashboard.currencies.edit', $currency) }}" class="btn btn-outline-primary btn-sm">
        <i class="fas fa fa-fw fa-edit"></i>
    </a>
@endcan
