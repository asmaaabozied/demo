<x-layout :title="trans('home_offers.plural')" :breadcrumbs="['dashboard.categories.index']">
    @include('dashboard.home_offers.partials.list')
</x-layout>
