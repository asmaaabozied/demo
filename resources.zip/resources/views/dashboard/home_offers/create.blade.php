<x-layout :title="trans('home_offers.actions.create')" :breadcrumbs="['dashboard.categories.create']">
    @include('dashboard.home_offers.partials.create-box')
</x-layout>
