@can('update', $home_offer)
    <a href="{{ route('dashboard.home-offers.edit', $home_offer) }}" class="btn btn-outline-primary btn-sm">
        <i class="fas fa fa-fw fa-edit"></i>
    </a>
@endcan
