    <a href="{{ route('dashboard.home-offers.create') }}" class="btn btn-outline-success btn-sm">
        <i class="fas fa fa-fw fa-plus"></i>
        @lang('home_offers.actions.create')
    </a>
