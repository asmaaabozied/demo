@can('update', $location)
    <a href="{{ route('dashboard.locations.edit', $location) }}" class="btn btn-outline-primary btn-sm">
        <i class="fas fa fa-fw fa-edit"></i>
    </a>
@endcan
