<x-layout :title="trans('offers.plural')" :breadcrumbs="['dashboard.offers.index']">
    @include('dashboard.offers.partials.list')
</x-layout>
