<x-layout :title="trans('offers.actions.create')" :breadcrumbs="['dashboard.offers.create']">
    @include('dashboard.offers.partials.create-box')
</x-layout>