@can('update', $size)
    <a href="{{ route('dashboard.sizes.edit', $size) }}" class="btn btn-outline-primary btn-sm">
        <i class="fas fa fa-fw fa-edit"></i>
    </a>
@endcan
