@can('update', $governorate)
    <a href="{{ route('dashboard.governorates.edit', $governorate) }}" class="btn btn-outline-primary btn-sm">
        <i class="fas fa fa-fw fa-edit"></i>
    </a>
@endcan
