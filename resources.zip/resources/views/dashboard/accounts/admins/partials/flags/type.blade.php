<span class="badge text-white bg-purple">{{ $admin->present()->type }}</span>
