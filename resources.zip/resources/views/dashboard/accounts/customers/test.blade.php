<?php
        foreach($post['address'] as $key => $value)
            {
                insert = $post['address'][$key] $post['city'][$key]
            }
