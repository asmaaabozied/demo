<span class="badge badge-success">{{ $customer->present()->type }}</span>
