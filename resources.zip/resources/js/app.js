// require('./bootstrap');
import FileUploader from 'laravel-file-uploader';

Vue.use(FileUploader);
