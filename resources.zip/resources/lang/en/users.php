<?php

return [
    'plural' => 'Accounts',
    'types' => [
        'admin' => 'Admin',
        'customer' => 'Customer',
        '' => 'types.',
    ],
    'impersonate' => [
        'go' => 'Go To Dashboard',
        'leave' => 'Back To Previous Account',
    ],
];