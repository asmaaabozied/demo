<?php

return [
    'plural' => 'العضويات',
    'types' => [
        'admin' => 'مسئول',
        'customer' => 'عميل',
        '' => 'types.',
    ],
    'impersonate' => [
        'go' => 'الذهاب للوحة التحكم',
        'leave' => 'العودة للحساب السابق',
    ],
];