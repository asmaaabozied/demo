<?php

return [
    'errorLoading' => 'لا يمكن تحميل النتائج',
    'inputTooLong' => 'الرجاء حذف :overChars عناصر',
    'inputTooShort' => 'الرجاء اضافة :remainingChars عناصر',
    'loadingMore' => 'جاري تحميل نتائج إضافية...',
    'maximumSelected' =>  'تستطيع إختيار :maximum بنود فقط',
    'noResults' =>  'لم يتم العثور على أي نتائج',
    'searching' =>  'جاري البحث …',
    'removeAllItems' =>  'قم بإزالة كل العناصر',
];
